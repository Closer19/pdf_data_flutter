package com.example.oauth2_naver_google.controller;
import com.example.oauth2_naver_google.jwt.JwtUtil;
import jakarta.servlet.http.Cookie;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;

@RestController
@RequiredArgsConstructor
public class NaverLoginController {
    private final JwtUtil jwtUtil;

    @Value("${naver.client-id}")
    private String clientId;

    @Value("${naver.client-secret}")
    private String clientSecret;

    @Value("${naver.redirect-uri}")
    private String redirectUri;

    private final RestTemplate restTemplate = new RestTemplate();

    // Step 1: Redirect to Naver OAuth2 authorization URL
    @GetMapping("/naver")
    public ResponseEntity<?> redirectToNaver() {
        String authorizationUrl = UriComponentsBuilder.fromHttpUrl("https://nid.naver.com/oauth2.0/authorize")
                .queryParam("client_id", clientId)
                .queryParam("redirect_uri", redirectUri)
                .queryParam("response_type", "code")
                .queryParam("state", "randomState") // CSRF 방지를 위해 사용
                .toUriString();

        return ResponseEntity.status(HttpStatus.FOUND).header(HttpHeaders.LOCATION, authorizationUrl).build();
    }

    // Step 2: Handle redirect with authorization code from Naver
    @GetMapping("/login/oauth2/code/naver")
    public ResponseEntity<?> handleNaverCallback(
            @RequestParam Map<String, String> params) {
        String code = params.get("code");
        String state = params.get("state");

        // Step 3: Exchange authorization code for access token
        String tokenUrl = "https://nid.naver.com/oauth2.0/token";

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        String body = "grant_type=authorization_code" +
                "&client_id=" + clientId +
                "&client_secret=" + clientSecret +
                "&code=" + code +
                "&state=" + state;

        HttpEntity<String> request = new HttpEntity<>(body, headers);

        ResponseEntity<Map> tokenResponse = restTemplate.exchange(
                tokenUrl, HttpMethod.POST, request, Map.class
        );

        if (!tokenResponse.getStatusCode().is2xxSuccessful()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Failed to get access token");
        }

        String accessToken = (String) tokenResponse.getBody().get("access_token");

        // Step 4: Use access token to get user information
        String userInfoUrl = "https://openapi.naver.com/v1/nid/me";
        HttpHeaders userHeaders = new HttpHeaders();
        userHeaders.setBearerAuth(accessToken);

        HttpEntity<Void> userRequest = new HttpEntity<>(userHeaders);

        ResponseEntity<Map> userInfoResponse = restTemplate.exchange(
                userInfoUrl, HttpMethod.GET, userRequest, Map.class
        );

        if (!userInfoResponse.getStatusCode().is2xxSuccessful()) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Failed to get user info");
        }

        Map<String, Object> response = (Map<String, Object>) userInfoResponse.getBody().get("response");
        String email = (String) response.get("email");
        String name = (String) response.get("name");
        String role = "ROLE_USER";

        // Step 5: Generate JWT token
        String jwtToken = this.jwtUtil.CreateJwt("access", name, role, 60 * 10 * 1000L);

        if(redirectUri.startsWith("http://10.0.2.2")){
           return ResponseEntity.status(HttpStatus.OK).body(jwtToken);
        }

        String redirectUrl = "http://localhost:3000/test"; // 리다이렉트 대상 URL
        // 쿠키 생성
        Cookie cookie = new Cookie("Authorization", jwtToken);
        cookie.setHttpOnly(false); // XSS 공격 방지
        cookie.setSecure(false); // HTTPS 환경에서는 true로 설정
        cookie.setPath("/"); // 쿠키가 모든 경로에서 유효하도록 설정
        cookie.setMaxAge(60 * 10); // 쿠키 유효기간 (초 단위)

        // Set-Cookie 헤더 추가
        HttpHeaders responseHeaders = new HttpHeaders();
        responseHeaders.add(HttpHeaders.SET_COOKIE, String.format("Authorization=%s; Path=/", jwtToken));
        responseHeaders.set(HttpHeaders.LOCATION, redirectUrl);


        return ResponseEntity.status(HttpStatus.FOUND).headers(responseHeaders).build();
    }
}

