package com.example.oauth2_naver_google.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RequestController {
    @GetMapping("/req")
    public String getRequest() {
        return "Hello World";
    }

    @GetMapping("/admin")
    public String getAdmin() {
        return "Hello admin!!";
    }
}
