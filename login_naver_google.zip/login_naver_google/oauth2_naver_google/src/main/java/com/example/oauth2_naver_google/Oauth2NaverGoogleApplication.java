package com.example.oauth2_naver_google;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2NaverGoogleApplication {

    public static void main(String[] args) {
        SpringApplication.run(Oauth2NaverGoogleApplication.class, args);
    }

}
