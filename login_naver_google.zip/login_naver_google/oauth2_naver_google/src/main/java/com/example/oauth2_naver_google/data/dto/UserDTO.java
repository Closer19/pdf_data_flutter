package com.example.oauth2_naver_google.data.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String role;
    private String name;
    private String username;
}
