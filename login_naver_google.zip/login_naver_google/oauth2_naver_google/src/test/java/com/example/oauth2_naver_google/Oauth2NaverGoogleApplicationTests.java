package com.example.oauth2_naver_google;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Oauth2NaverGoogleApplicationTests {

    @Test
    void contextLoads() {
    }

}
