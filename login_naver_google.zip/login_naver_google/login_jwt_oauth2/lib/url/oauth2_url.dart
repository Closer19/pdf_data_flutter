String serverIp="http://10.0.2.2:8080";

class Oauth2Url{
  static final googleRedirectUrl="${serverIp}/login/oauth2/code/google";
  static final naverRedirectUrl="${serverIp}/login/oauth2/code/naver";
  static final googleAuthenUrl= "${serverIp}/google";
  static final naverAuthenUrl= "${serverIp}/naver";
}


