import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: Mypage(),
    );
  }
}

class Mypage extends StatelessWidget {
  const Mypage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        foregroundColor: Colors.white,
        title: Text('Appbar icon menu'),
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: (){
                print('shopping cart button is clicked');
              },
              icon: Icon(Icons.shopping_cart),
          ),
          IconButton(
              onPressed: (){
                print('search button is clicked');
              },
              icon: Icon(Icons.search),
          )
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.red[200],
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(40.0),
                    bottomRight: Radius.circular(40.0),
                  )
                ),
                accountName: Text("prettkja"),
                accountEmail: Text("prettkja@naver.com"),
                currentAccountPicture: CircleAvatar(
                  backgroundImage: AssetImage("images/lgtwins.jpg"),
                  radius: 60.0,
                ),
              onDetailsPressed: (){
                  print('arrow is clicked');
              },
            ),
            ListTile(
              leading: Icon(Icons.home,
                  color: Colors.grey[700],),
              title: Text("home"),
              onTap: (){
                print("home is clicked");
              },
              trailing: Icon(Icons.add),
            ),
            ListTile(
              leading: Icon(Icons.settings,
                color: Colors.grey[700],),
              title: Text("Settings"),
              onTap: (){
                print("settings is clicked");
              },
              trailing: Icon(Icons.add),
            ),
            ListTile(
              leading: Icon(Icons.question_answer,
                color: Colors.grey[700],),
              title: Text("QnA"),
              onTap: (){
                print("QnA is clicked");
              },
              trailing: Icon(Icons.add),
            ),

          ],
        ),

      ),

    );
  }
}

