import 'package:flutter/material.dart';
import './dice.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dice game',
      home: Login(),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController nameCtlor=TextEditingController();
  TextEditingController passwordCtlor=TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: (){},
              icon: Icon(Icons.search),
          )
        ],
      ),
      body: GestureDetector(
        onTap: (){
          FocusScope.of(context).unfocus();
        },
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: Image.asset("images/sun-15710_256.gif"),
              ),
              Form(
                  child: Theme(
                    data: ThemeData(
                      inputDecorationTheme: InputDecorationTheme(
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.pinkAccent),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.teal),
                        ),
                        labelStyle: TextStyle(
                          color: Colors.green,
                          fontSize: 20.0
                        )
                      )
                    ),
                    child: Container(
                      padding: EdgeInsets.all(60),
                      child: Column(
                        children: [
                          TextField(
                            controller: nameCtlor,
                            decoration: InputDecoration(
                              labelText: 'Enter "Dice"',
                            ),
                            keyboardType: TextInputType.emailAddress,
                          ),
                          TextField(
                            controller: passwordCtlor,
                            decoration: InputDecoration(
                              labelText: 'Enter "Password"',
                            ),
                            keyboardType: TextInputType.text,
                            obscureText: true,
                          ),
                          SizedBox(
                            height: 150,
                          ),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orangeAccent,
                                minimumSize: Size(100, 50),
                              ),
                              onPressed: (){
                                if(nameCtlor.text == 'Dice' &&
                                   passwordCtlor.text == '1234'){
                                  Navigator.push(context, MaterialPageRoute(
                                      builder: (BuildContext context) => Dice()));
                                }else if( nameCtlor.text != 'Dice' ||
                                    passwordCtlor.text != '1234'){
                                  showSnackBar(context, "로그인 정보를 확인하세요");
                                }
                              },
                              child: Icon(Icons.arrow_forward,
                              color: Colors.white,
                              size: 35.0,))
                        ],
                      ),
                    ),
                  )
              )
            ],
          ),
        ),
      ),
    );
  }
}

void showSnackBar(BuildContext context, String str){
  ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(str,
          textAlign: TextAlign.center,),
          duration: Duration(seconds: 2),
          backgroundColor: Colors.blue,
      ),
  );
}
