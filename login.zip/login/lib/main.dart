import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import 'dart:convert';
import './user_info.dart';
import './dice.dart';
import './token_info.dart';

void main() {
  runApp(ChangeNotifierProvider(
      create: (context)=>TokenInfo(),
      child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dice game',
      home: Login(),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  UserInfo? userInfo=null;

  String? responseError=null;
  bool isLogin=false;

  TextEditingController nameCtlor=TextEditingController();
  TextEditingController passwordCtlor=TextEditingController();

  Future<void> loginRequest(BuildContext context) async{
    TokenInfo provider=context.read<TokenInfo>();

    final url=Uri.parse("http://10.0.2.2:8080/api/login");
    final body=userInfo!.toJson();

    try{
      final response= await http.post(url, body: body);

      if(response.statusCode==200){
        setState(() {
          isLogin=true;
        });
        final refresh=response.headers['set-cookie'];
        final access=response.headers['authorization'];
        provider.saveAccessToken(access);
        provider.saveRefreshToken(refresh);
      }else if(response.statusCode==401) {
        responseError=utf8.decode(response.bodyBytes);
      }else{
        setState(() {
          responseError='Error: ${response.statusCode}';
        });
      }
    }catch(e){
      responseError = 'Error: $e';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
        actions: [
          IconButton(
              onPressed: (){},
              icon: Icon(Icons.search),
          )
        ],
      ),
      body: GestureDetector(
        onTap: (){
          FocusScope.of(context).unfocus();
        },
        child: SingleChildScrollView(
          child: Column(
            children: [
              Center(
                child: Image.asset("images/sun-15710_256.gif"),
              ),
              Form(
                  child: Theme(
                    data: ThemeData(
                      inputDecorationTheme: InputDecorationTheme(
                        focusedBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.pinkAccent),
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderSide: BorderSide(color: Colors.teal),
                        ),
                        labelStyle: TextStyle(
                          color: Colors.green,
                          fontSize: 20.0
                        )
                      )
                    ),
                    child: Container(
                      padding: EdgeInsets.all(60),
                      child: Column(
                        children: [
                          TextField(
                            controller: nameCtlor,
                            decoration: InputDecoration(
                              labelText: 'Enter "Dice"',
                            ),
                            keyboardType: TextInputType.emailAddress,
                          ),
                          TextField(
                            controller: passwordCtlor,
                            decoration: InputDecoration(
                              labelText: 'Enter "Password"',
                            ),
                            keyboardType: TextInputType.text,
                            obscureText: true,
                          ),
                          SizedBox(
                            height: 150,
                          ),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.orangeAccent,
                                minimumSize: Size(100, 50),
                              ),
                              onPressed: (){
                                setState(() {
                                  userInfo=UserInfo(username: nameCtlor.text, password: passwordCtlor.text);
                                });
                                loginRequest(context).then((_){
                                  if(isLogin){
                                    Navigator.push(context, MaterialPageRoute(
                                        builder: (context)=>Dice()));
                                  }else{
                                    showSnackBar(context, responseError!);
                                  }
                                });
                              },
                              child: Icon(Icons.arrow_forward,
                              color: Colors.white,
                              size: 35.0,))

                        ],
                      ),
                    ),
                  )
              )
            ],
          ),
        ),
      ),
    );
  }
}

void showSnackBar(BuildContext context, String str){
  ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(str,
          textAlign: TextAlign.center,),
          duration: Duration(seconds: 2),
          backgroundColor: Colors.blue,
      ),
  );
}
