import 'package:flutter/material.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import './token_info.dart';
import 'dart:convert';

class Dice extends StatefulWidget {
  const Dice({super.key});


  @override
  State<Dice> createState() => _DiceState();
}

class _DiceState extends State<Dice> {
  int leftDice=1;
  int rightDice=1;

  String? responseMessage=null;
  String? errorMessage=null;
  bool isAdmin=false;

  Future<http.Response> adminRequest(BuildContext context) async{
    TokenInfo provider = context.read<TokenInfo>();

    final url=Uri.parse("http://10.0.2.2:8080/api/admin");
    final headers={"authorization":provider.accessToken!};
    late final response;
    try{
      response= await http.get(url, headers: headers);
      if(response.statusCode==200){
        setState(() {
          responseMessage=utf8.decode(response.bodyBytes);
          isAdmin=true;
        });
      }else if(response.statusCode==401){
        await accessTokenRequest(context);

        return adminRequest(context);

      }else if(response.statusCode==403){
        setState(() {
          errorMessage=utf8.decode(response.bodyBytes);
        });
      }
    }catch(e){
      errorMessage = 'Error: ${e}';
    }

    return response;
  }

  Future<void> accessTokenRequest(BuildContext context) async{
    TokenInfo provider= context.read<TokenInfo>();
    print("access token 재발급 요청");

    final url=Uri.parse("http://10.0.2.2:8080/api/reissue");
    final headers={ 'Cookie':provider.refreshToken!};

    try{
      final response= await http.post(url, headers: headers);

      if(response.statusCode==200){
        final access=response.headers["authorization"];
        provider.saveAccessToken(access);
      }else{
        print('Error: ${response.statusCode}');
      }
    }catch(e){
      print('Error: ${e}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.redAccent,
      appBar: AppBar(
        title: Text("Dice game"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(30.0),
              child: Row(
                children: [
                  Expanded(
                      child: Image.asset('images/dice$leftDice.png')
                  ),
                  SizedBox(
                    width: 20.0,
                  ),
                  Expanded(
                      child: Image.asset('images/dice$rightDice.png')
                  )
                ],
              ),
            ),
            SizedBox(
              height: 40.0,
            ),
            ElevatedButton(
                onPressed: () async {
                  await adminRequest(context);
                  if (isAdmin) {
                    setState(() {
                      rightDice = Random().nextInt(6) + 1;
                      leftDice = Random().nextInt(6) + 1;
                    });
                    showSnackBar(context, responseMessage!);
                  } else {
                    showSnackBar(context, errorMessage!);
                  }
                },
                child: Icon(Icons.play_arrow,
                color: Colors.white,
                size: 50.0,),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orangeAccent,
                ),
            )
          ],
        ),
      ),
    );
  }
}
void showSnackBar(BuildContext context, String str){
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(str,
        textAlign: TextAlign.center,),
      duration: Duration(seconds: 2),
      backgroundColor: Colors.blue,
    ),
  );
}


