import 'package:flutter/material.dart';
import 'dart:math';
import 'package:http/http.dart' as http;
import './token_info.dart';
import 'dart:convert';
import 'package:provider/provider.dart';

class Dice extends StatefulWidget {
  const Dice({super.key});

  @override
  State<Dice> createState() => _DiceState();
}

class _DiceState extends State<Dice> {
  int leftDice = 1;
  int rightDice= 1;
  String? responseMessge=null;
  String? errorMessage=null;
  bool isAdmin=false;

  Future<http.Response> adminRequest(BuildContext context) async {
    TokenInfo provider = context.read<TokenInfo>();

    final url = Uri.parse('http://10.0.2.2:8080/admin');

    final headers = {
      'Cookie': 'Authorization=${provider.accessToken!}',
      'Content-Type': 'application/json', // 필요에 따라 추가
    };
    late final response;
    try {

      response = await http.get(url, headers: headers);

      if (response.statusCode == 200) {
        // final data = utf8.decode(response.bodyBytes);
        setState(() {
          responseMessge = utf8.decode(response.bodyBytes);
          isAdmin=true;
        });

      }else if(response.statusCode == 401 || response.statusCode == 403){
        setState(() {
          errorMessage = utf8.decode(response.bodyBytes);
        });
      }
    } catch (e) { //서버에 요청이 도달하지 않았을때
      errorMessage = 'Error: ${e}';
    }
    return response;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.redAccent,
      appBar: AppBar(
        title: Text("Dice Game"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: EdgeInsets.all(32.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: Image.asset('images/dice$leftDice.png',
                    width: 300,),
                  ),
                  SizedBox(
                    width: 20.0,
                  ),
                  Expanded(
                    child: Image.asset('images/dice$rightDice.png',
                      width: 300,),
                  ),
                ],
              ),

            ),
            SizedBox(
              height: 60,
            ),
            ButtonTheme(
              minWidth: 100.0,
              height: 60.0,
              child: ElevatedButton(
                  onPressed: () async{
                    await adminRequest(context);
                    if(isAdmin){
                      setState(() {
                        rightDice = Random().nextInt(6) +1;
                        leftDice = Random().nextInt(6) + 1;
                      });
                      showSnackBar(context,responseMessge!);
                    }else{
                      showSnackBar(context, errorMessage!);
                    }

                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orangeAccent,
                  ),
                  child: Icon(Icons.play_arrow,
                  color: Colors.white,
                  size: 50.0,)),

            )
          ],
        ),
      ),
      );
  }
}

void showSnackBar(BuildContext context, String str){
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        str,
        textAlign: TextAlign.center,
      ),
      duration: Duration(seconds: 2),
      backgroundColor: Colors.blue,
    ),
  );
}



