import 'package:flutter/material.dart';
import 'package:login/social.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import './token_info.dart';
import './dice.dart';

class SocialAuthScreen extends StatefulWidget {

  @override
  _SocialAuthScreenState createState() => _SocialAuthScreenState();
}

class _SocialAuthScreenState extends State<SocialAuthScreen> {
  late final WebViewController _controller;
  String? loginMessge=null;
  String? url=null;
  
  @override
  void initState() {
    super.initState();
    Social provider=context.read<Social>();
    if(provider.socialName=="Naver"){
      url="http://10.0.2.2:8080/oauth2/authorization/naver";
    }else if(provider.socialName=="Google"){
      url="http://10.0.2.2:8080/oauth2/authorization/google";
    }else{
      return;
    }    
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (String url){ // 페이지 로딩 시작
          },
          onPageFinished: (String url){       // 페이지 로딩 완료
          },
          onNavigationRequest: (NavigationRequest request) async{
          if(request.url.startsWith("http://localhost:3000/token")){
            Uri url=Uri.parse(request.url);
            String? access=url.queryParameters['accesstoken'];
            TokenInfo provider=context.read<TokenInfo>();
            provider.saveAccessToken(access);

            if(access!=null){
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Dice(),
                  ));
              return NavigationDecision.prevent;
            }
          }
          return NavigationDecision.navigate;
        }
      ))
      ..loadRequest(Uri.parse(url!));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Social Authentication'),
      ),
      body: WebViewWidget(
        controller: _controller, // WebViewController 연결
      ),
    );
  }
}
