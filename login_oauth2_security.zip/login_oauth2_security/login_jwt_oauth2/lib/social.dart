import 'package:flutter/material.dart';

class Social extends ChangeNotifier{

  String socialName="NoSelect";

  void saveSocial(String socialName){
    this.socialName=socialName;
    notifyListeners();
  }

}