import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:login/social.dart';
import 'dice.dart';
import './user_info.dart';
import 'dart:convert';
import 'package:provider/provider.dart';
import './token_info.dart';
import './socialLogin.dart';

void main() {

  runApp(
  MultiProvider(providers: [
    ChangeNotifierProvider<TokenInfo>(create: (context) => TokenInfo()),
    ChangeNotifierProvider<Social>(create: (context)=> Social()),
  ],
    child: MyApp(),));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dice game',
      home: Login(),
    );
  }
}

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  UserInfo? userInfo=null;

  String? responseError=null;
  // String? loginMessage=null;
  //
  // TextEditingController controller=TextEditingController();
  // TextEditingController controller2=TextEditingController();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();

  }

  // Future<void> loginRequest(BuildContext context) async {
  //   TokenInfo provider = context.read<TokenInfo>();
  //
  //   final url = Uri.parse('http://10.0.2.2:8080/login');
  //   final body= userInfo!.toJson();
  //
  //   try {
  //     final response = await http.post(url, body: body);
  //
  //     if (response.statusCode == 200) {
  //       // final data = utf8.decode(response.bodyBytes);
  //       loginMessage = utf8.decode(response.bodyBytes);
  //       final cookies=response.headers['set-cookie'];
  //       final access=getCookieValue(cookies.toString(), "Authorization");
  //       provider.saveAccessToken(access);
  //
  //     } else {
  //       setState(() {
  //         responseError = 'Error: ${response.statusCode}';
  //       });
  //     }
  //   } catch (e) {
  //     setState(() {
  //       responseError = 'Error: $e';
  //     });
  //   }
  // }
  //
  // String? getCookieValue(String cookies, String key) {
  //   // 쿠키 문자열을 ';'로 분리
  //   final cookieList = cookies.split('; ');
  //   for (final cookie in cookieList) {
  //     // 키=값 형태를 '='로 분리
  //     if (cookie.startsWith('$key=')) {
  //       return cookie.split('=')[1]; // 키 뒤의 값을 반환
  //     }
  //   }
  //   return null; // 키가 없으면 null 반환
  // }




  @override
  Widget build(BuildContext context) {
    Social provider = context.read<Social>();
    return Scaffold(
      appBar: AppBar(
        title: Text("Login"),
        backgroundColor: Colors.redAccent,
        centerTitle: true,
        // leading: IconButton(onPressed: () {}, icon: Icon(Icons.menu)),
        actions: [
          IconButton(onPressed: () {}, icon: Icon(Icons.search)),
        ],
      ),
      body: Builder(
        builder:(context) {
          return GestureDetector(
            onTap: (){
              FocusScope.of(context).unfocus();
            },
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Padding(padding: EdgeInsets.only(top: 50)),
                  Center(
                    child: Image(
                      image: AssetImage("images/chef.gif"),
                      width: 170.0,
                      height: 190.0,
                    ),
                  ),
                  Form(
                      child: Theme(
                          data: ThemeData(
                            // primaryColor: Colors.teal,
                              inputDecorationTheme: InputDecorationTheme(
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.teal),
                                  ),
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.teal),
                                  ),
                                  labelStyle: TextStyle(
                                    color: Colors.teal,
                                    fontSize: 15.0,
                                  ))),
                          child: Container(
                            padding: EdgeInsets.all(40.0),
                            child: Column(
                              children: [
                               //  TextField(
                               //    controller: controller,
                               //    decoration: InputDecoration(
                               //      labelText: 'Enter "Dice"',
                               //    ),
                               //    keyboardType: TextInputType.emailAddress,
                               //  ),
                               //  TextField(
                               //    controller: controller2,
                               //    decoration: InputDecoration(
                               //      labelText: 'Enter "Password"',
                               //    ),
                               //    keyboardType: TextInputType.text,
                               //    obscureText: true,
                               //  ),
                               //  SizedBox(
                               //    height: 40.0,
                               //  ),
                               // ElevatedButton(
                               //        style: ElevatedButton.styleFrom(
                               //          backgroundColor: Colors.orangeAccent,
                               //          minimumSize: Size(100,50),
                               //        ),
                               //        onPressed: () {
                               //          setState(() {
                               //            userInfo=UserInfo(username: controller.text, password: controller2.text);
                               //          });
                               //          loginRequest(context).then((_){
                               //            Navigator.push(context, MaterialPageRoute(
                               //                builder: (context)=>Dice()));
                               //          }
                               //          );
                               //
                               //        },
                               //        child: Icon(
                               //          Icons.arrow_forward,
                               //          color: Colors.white,
                               //          size: 35.0,
                               //        )
                               //    ),
                               // SizedBox(
                               //   height: 30,
                               // ),
                               GestureDetector(
                                 onTap: () async{
                                   provider.saveSocial("Naver");
                                   Navigator.push(
                                       context,
                                       MaterialPageRoute(
                                       builder: (context) => SocialAuthScreen(),
                                   ));
                                 },
                                 child: Container(
                                   child: Image.asset("images/naver.jpg"),
                                 ),
                               ),
                                SizedBox(
                                  height: 30,
                                ),
                                GestureDetector(
                                  onTap: () async{
                                    provider.saveSocial("Google");
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) => SocialAuthScreen(),
                                        ));
                                  },

                                  child: Container(
                                    child: Image.asset("images/google.png"),
                                  ),
                                ),
                              ],
                            ),
                          )
                      )
                  )
                ],
              ),
            ),
          );
        }
      ),
    );
  }
}

void showSnackBar(BuildContext context, String? str){
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(
        str!,
        textAlign: TextAlign.center,
        ),
      duration: Duration(seconds: 2),
      backgroundColor: Colors.blue,
    ),
  );
}

