import React, {useState} from "react";

function Login() {
    const handleNaverLogin=()=>{
        window.location.href = "http://localhost:8080/oauth2/authorization/naver";
    }

    const handleGoogleLogin=()=>{
        window.location.href = "http://localhost:8080/oauth2/authorization/google";
    }

    return (
        <div>
            <button onClick={handleNaverLogin}>네이버로 로그인</button>
            <button onClick={handleGoogleLogin}>구글로 로그인</button>
        </div>
    );
}

export default Login;
