import axios from "axios";

export default function TestConponent(){
    const handleRequest=async ()=>{
        try{
            const response=await axios.get("http://localhost:8080/admin",
                {
                    withCredentials:true,
                });

            alert(response.data);

        }catch(error){
            console.log(error.message);
        }
    }
        return(
        <>
        <h1>로그인 되었습니다.</h1>
            <button onClick={handleRequest}>request</button>
        </>
    );
}