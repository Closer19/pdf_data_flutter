
import './App.css';
import Login from "./Login";
import TestConponent from "./TestConponent";
import {BrowserRouter, Routes, Route, Navigate} from "react-router-dom";
function App() {

  return (
    <>
        <BrowserRouter>
            <Routes>
                <Route path={"/"} element={<Login/>}></Route>
                <Route path={"/token"} element={<Navigate to="/test" replace />}></Route>
                <Route path={"/test"} element={<TestConponent/>}></Route>
            </Routes>
        </BrowserRouter>
    </>
  );
}


export default App;
