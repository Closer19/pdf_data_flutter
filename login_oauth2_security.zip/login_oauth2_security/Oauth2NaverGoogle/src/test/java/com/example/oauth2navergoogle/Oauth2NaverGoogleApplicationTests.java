package com.example.oauth2navergoogle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class Oauth2NaverGoogleApplicationTests {

    @Test
    void contextLoads() {
    }

}
