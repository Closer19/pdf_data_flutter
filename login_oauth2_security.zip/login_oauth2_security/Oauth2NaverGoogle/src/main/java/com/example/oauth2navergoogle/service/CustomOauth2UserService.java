package com.example.oauth2navergoogle.service;

import com.example.oauth2navergoogle.dto.*;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

@Service
public class CustomOauth2UserService extends DefaultOAuth2UserService {
    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException{
        OAuth2User oAuth2User = super.loadUser(userRequest);
        System.out.println(oAuth2User);

        String registerId=userRequest.getClientRegistration().getRegistrationId();

        OAuth2Response oAuth2Response=null;
        if(registerId.equals("naver")){
            oAuth2Response=new NaverOAuth2Response(oAuth2User.getAttributes());
        }else if(registerId.equals("google")){
            oAuth2Response=new GoogleOAuth2Response(oAuth2User.getAttributes());
        }
        else{
            return null;
        }

        String username=oAuth2Response.getProvider()+oAuth2Response.getProviderId();
        System.out.println("유저이름:"+username);

        UserDTO userDTO=new UserDTO();
        userDTO.setUsername(username);
        userDTO.setName(oAuth2Response.getName());
        userDTO.setRole("ROLE_USER");

        return new CustomOAuth2User(userDTO);
    }
}
