package com.example.oauth2navergoogle.controller;

import com.example.oauth2navergoogle.jwt.JwtUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {

    private final JwtUtil jwtUtil;

    public MainController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @GetMapping(value="/admin")
    public String admin() {
        return "관리자입니다.";
    }
}
