package com.example.oauth2navergoogle.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String username;
    private String name;
    private String role;
}
