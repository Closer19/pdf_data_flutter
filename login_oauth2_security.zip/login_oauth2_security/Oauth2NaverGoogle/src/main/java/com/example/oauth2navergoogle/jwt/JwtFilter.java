package com.example.oauth2navergoogle.jwt;

import com.example.oauth2navergoogle.dto.CustomOAuth2User;
import com.example.oauth2navergoogle.dto.UserDTO;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
@RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
    private final JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        Cookie[] cookies = request.getCookies();
        String accessToken=null;
        // 토큰이 없다면 다음 필터로 넘김
        if(cookies != null){
            for(Cookie cookie : cookies) {
                if(cookie.getName().equals("Authorization")) {
                    accessToken = cookie.getValue();
                    break;
                }
            }
        }

        if(accessToken == null) {
            System.out.println("token null");
            filterChain.doFilter(request, response);
            return;
        }

        try{
            this.jwtUtil.isExpired(accessToken);
        }catch(ExpiredJwtException e){
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setCharacterEncoding("UTF-8");
            response.getWriter().write("만료된 토큰");
            return;
        }

        String category = jwtUtil.getCategory(accessToken);
        if (!category.equals("access")) {
            //response body
            response.getWriter().write("invalid access token");
            //response status code
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            return;
        }

        String username=this.jwtUtil.getUsername(accessToken);
        String role=this.jwtUtil.getRole(accessToken);

        UserDTO userDTO=new UserDTO();
        userDTO.setUsername(username);
        userDTO.setRole(role);

        CustomOAuth2User customOAuth2User=new CustomOAuth2User(userDTO);

        Authentication authentication=new UsernamePasswordAuthenticationToken(customOAuth2User,null,customOAuth2User.getAuthorities());

        SecurityContextHolder.getContext().setAuthentication(authentication);
        filterChain.doFilter(request, response);
    }
}
