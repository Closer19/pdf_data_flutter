package com.example.nevigator2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
