// class Person{
//   late String name;
//   late int age;
//
//   Person(String name, int age){
//     this.name=name;
//     this.age=age;
//   }
// }
//
//
// void main() {
//   Person p1=new Person("kim", 30);
//   Person p2= Person("jin", 20);
// }
///////////////////////////////////////////////////////////////////////

// class Person{
//   late String? name;
//   late int age;
//
//   Person(String? name, int age){
//     this.name=name;
//     this.age=age;
//   }
// }
//
//
// void main() {
//   Person p1=new Person("kim", 30);
//   Person p2= Person(null, 20);
// }

///////////////////////////////////////////////////////////////////////

// class Person{
//   late String name;
//   late int age;
//
//   Person({String name="kim", int age=20}){
//     this.name=name;
//     this.age=age;
//   }
// }
//
// void main() {
//   Person p1=new Person();
//   print("${p1.name}, ${p1.age}");
// }

// class Person{
//   late String name;
//   late int age;
//
//   Person({String name="kim", int age=20}){
//     this.name=name;
//     this.age=age;
//   }
// }
//
// void main() {
//   Person p1=new Person(name:"jin");
//   print("${p1.name}, ${p1.age}");
// }
///////////////////////////////////////////////////////////////////////
//
// class Person{
//   String name;
//   int age;
//
//   Person({required this.name, required this.age});
// }
//
// void main() {
//   Person p1=new Person(name:"jin", age:20);
//   print("${p1.name}, ${p1.age}");
// }
