import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

void main(){
  runApp(Myapp()); // runApp(Myapp(key: Key("aaaa")));
}

class Myapp extends StatelessWidget {
  const Myapp({super.key}); //불변 객체를 만든다.

  @override
  Widget build(BuildContext context) { // BuildContext 위젯의 앱내서의 위치정보와 관계정보
    return MaterialApp(
      // debugShowCheckedModeBanner: false,
      title: 'LG Twins', //앱의 이름을 논리적으로 설정하기 위한 용도
      home: Grade(),
    );
  }
}

class Grade extends StatelessWidget {
  const Grade({super.key});

  @override
  Widget build(BuildContext context) { //flutter framework가 호출
    return Scaffold(
      backgroundColor: Colors.purple[300],
      appBar: AppBar(
        title: Text("LG Twins"),
        backgroundColor: Colors.purple[400],
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.fromLTRB(30.0, 40.0, 30.0, 40.0),
        child: Column(          
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Center(
            //   child: CircleAvatar(
            //     backgroundImage: AssetImage("assets/ginger-9997_256.gif"),
            //     radius: 60.0,
            //   ),
            // ),
            CircleAvatar(
              backgroundImage: AssetImage("assets/lgtwins.jpg"),
              radius: 60.0,
              backgroundColor: Colors.purple[300],
            ),
            Divider(
              height: 60.0, //위와 아래의 간격
              color: Colors.purple,
              thickness: 5,
              // endIndent: 30.0,
            ),
            Text("Team Name",
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
            )),
            SizedBox(
              height: 10.0,
            ),
            Text("LG TWINS",
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
              fontSize: 40.0,
              fontWeight: FontWeight.bold
            ),),
            SizedBox(
              height: 30.0,
            ),
             Text("창단 년도",
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
            )),
            SizedBox(
              height: 10.0,
            ),
            Text("1990",
            style: TextStyle(
              color: Colors.white,
              letterSpacing: 2.0,
              fontSize: 28.0,
              fontWeight: FontWeight.bold
            ),),
            SizedBox(
              height: 30.0,
            ),
            Text("우승 년도",
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2.0,
                )),
            SizedBox(
              height: 10.0,
            ),
            TextButton.icon(
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
              ),
                onPressed: (){
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                        content: Text("2025년 우승 예정",
                          style: TextStyle(
                            fontSize: 25.0,
                            color: Colors.amberAccent,
                          ),
                          textAlign: TextAlign.center,),
                        backgroundColor: Colors.pink,

                        duration: Duration(milliseconds: 3000),

                  ));
                },
                label: Text("1990, 1994, 2023",
                  style: TextStyle(
                    fontSize: 25.0,
                    fontFamily: "Roboto",
                  ),),
                icon: Icon(Icons.local_cafe,
                  size: 30.0,
                  color: Colors.purple,),
            ),

            Text("현 감독",
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 2.0,
                )),
            SizedBox(
              height: 10.0,
            ),
            TextButton.icon(
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
              ),
              onPressed: (){
                Fluttertoast.showToast(
                  msg: "곧 교체될 예정",
                  gravity: ToastGravity.CENTER,
                  backgroundColor: Colors.deepPurple,
                  textColor: Colors.amberAccent,
                  fontSize: 25.0,
                  toastLength: Toast.LENGTH_LONG,
                );
              },
              label: Text("염 경 엽",
                style: TextStyle(
                  fontSize: 25.0,
                  fontFamily: "Roboto",
                ),),
              icon: Icon(Icons.delete_forever,
                size: 30.0,
                color: Colors.purple,),
            ),
            ],
        ))
    );
  }
}
