class Animal{
  final String name;
  final String imgPath;
  final String location;

  // Animal({required this.name, required this.location, required this.imgPath}); //축양형
  // Animal(this.name, this.imgPath, this.location);

Animal(String name, String location, String imgPath)
      : this.name = name,
        this.location = location,
        this.imgPath = imgPath;

}