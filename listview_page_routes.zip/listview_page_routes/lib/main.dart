import 'package:flutter/material.dart';

import 'animal_page.dart';
import 'model.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
     routes: {
       "/":(context)=>MyPage(),
       "/animal_page":(context)=>AnimalPage(),
     },
    );
  }
}

class MyPage extends StatefulWidget {
  const MyPage({super.key});


  @override
  State<MyPage> createState() => _MyPageState();
}

class _MyPageState extends State<MyPage> {

  static List<String> animalName=[
    'Bear',
    'Camel',
    'Deer',
    'Fox',
    'Kangaroo',
    'Koala',
    'Lion',
    'Tiger'
  ];

  static List<String> animalImagePath=[
    'images/bear.png',
    'images/camel.png',
    'images/deer.png',
    'images/fox.png',
    'images/kangaroo.png',
    'images/koala.png',
    'images/lion.png',
    'images/tiger.png'
  ];

  static List<String> animalLocation = [
    'forest and mountain',
    'dessert',
    'forest',
    'snow mountain',
    'Australia',
    'Australia',
    'Africa',
    'Korea'
  ];

  final List<Animal> animalData = List.generate(
    animalLocation.length,
      (index)=>Animal(
        animalName[index], animalLocation[index], animalImagePath[index]
      )
  );

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: const Text("ListView"),
      ),
      body: ListView.builder(
          itemCount: animalLocation.length,
          itemBuilder: (context, index){
            return Card(
              child: ListTile(
                title: Text(
                  animalData[index].name,
                ),
                leading: SizedBox(
                  height: 50,
                  width: 50,
                  child: Image.asset(animalData[index].imgPath),
                ),
                onTap: (){
                  // Navigator.of(context).push(MaterialPageRoute( //페이지간 이동처리를 위한 클래스
                  //     builder: (context)=>AnimalPage(animal:animalData[index],)));
                  //     debugPrint(animalData[index].name);
                  Navigator.pushNamed(context, "/animal_page", arguments: animalData[index]);
                },
              ),

              );
          }
      ),

    );
  }

}
