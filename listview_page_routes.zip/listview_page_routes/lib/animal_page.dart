import 'package:flutter/material.dart';

import 'model.dart';

class AnimalPage extends StatefulWidget {
  const AnimalPage({super.key});  // final Animal animal;


  @override
  State<AnimalPage> createState() => _AnimalPageState();
}

class _AnimalPageState extends State<AnimalPage> {

  bool isLiked = false;
  int likeCount = 0;

  late final Animal animal;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    animal = ModalRoute.of(context)?.settings.arguments as Animal ;

  }

  @override
  Widget build(BuildContext context) {
    // final Animal animal = ModalRoute.of(context)?.settings.arguments as Animal ;

    return Scaffold(
      appBar: AppBar(
        title: Text(animal.name),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 200,
              width: 200,
              child: Image.asset(animal.imgPath),
              //widget은 해당 State 객체에 연결된 StatefulWidget 인스턴스를 참조
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              'It lives in' + animal.location,
              style: const TextStyle(
                fontSize: 18,
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children:[
                IconButton(
                    onPressed: (){
                      setState(() {
                        isLiked=true;
                        likeCount++;
                      });
                    },
                    icon: Icon(Icons.favorite,
                      color: isLiked? Colors.redAccent:Colors.grey,
                      size: 40,)),
                Text("$likeCount",
                style: TextStyle(
                  fontSize: 25.0,
                  color: Colors.purple
                ),)

              ]
            )

          ],
        ),
      ),
    );
  }
}
